// Arena MCP Bridge — connects ws://127.0.0.1:8768 (localhost only).
// Local MCP sends {id, action, cmd}; we execute with chrome.* APIs and reply {id, ok, data, error}.
const PORT = 8768;
let ws = null;
let retry = 0;

function setBadge(on) {
  const p = {};
  for (const s of [16, 32, 48, 128]) p[s] = "icons/icon" + s + (on ? "" : "-off") + ".png";
  try { chrome.action.setIcon({ path: p }); } catch (e) {}
  try { chrome.action.setBadgeText({ text: "" }); } catch (e) {}
}

function connect() {
  if (ws && ws.readyState <= 1) return;
  try {
    ws = new WebSocket("ws://127.0.0.1:" + PORT);
  } catch (e) { schedule(); return; }
  ws.onopen = () => { retry = 0; setBadge(true); send({ t: "hello", agent: "arena-bridge" }); };
  ws.onmessage = (ev) => { let m; try { m = JSON.parse(ev.data); } catch (e) { return; } handle(m); };
  ws.onclose = () => { ws = null; setBadge(false); schedule(); };
  ws.onerror = () => { try { ws.close(); } catch (e) {} };
}
function schedule() { setTimeout(connect, Math.min(8000, 400 * ++retry)); }
function send(o) { if (ws && ws.readyState === 1) ws.send(JSON.stringify(o)); }
function reply(m, ok, data, error) { send({ id: m.id, ok: ok, data: data === undefined ? null : data, error: error || null }); }

function waitLoad(tabId) {
  return new Promise((res) => {
    const done = (id, info) => { if (id === tabId && info.status === "complete") { chrome.tabs.onUpdated.removeListener(done); res(); } };
    chrome.tabs.onUpdated.addListener(done);
    setTimeout(() => { chrome.tabs.onUpdated.removeListener(done); res(); }, 15000);
  });
}

function runInTab(tabId, func, args, world) {
  return chrome.scripting.executeScript({ target: { tabId: tabId }, func: func, args: args || [], world: world || "ISOLATED" })
    .then((r) => (r && r[0] ? r[0].result : null));
}

async function act(d) {
  const a = d.action;
  if (a === "eval") return await runInTab(d.tabId, (js) => eval(js), [d.selector], "MAIN");
  if (a === "scroll") return await runInTab(d.tabId, (px) => { window.scrollBy(0, px); }, [Number(d.text) || 600]);
  if (a === "press") return await runInTab(d.tabId, (k) => {
    const el = document.activeElement || document.body;
    el.dispatchEvent(new KeyboardEvent("keydown", { key: k, bubbles: true }));
    el.dispatchEvent(new KeyboardEvent("keyup", { key: k, bubbles: true }));
  }, [d.key || "Enter"]);
  return await runInTab(d.tabId, (sel, act2, txt) => {
    let el = null;
    if (sel.startsWith("text=")) {
      const want = sel.slice(5).trim();
      el = [...document.querySelectorAll("a,button,[role=button],input[type=submit],li,span,div,h1,h2,h3")]
        .find((n) => n.textContent && n.textContent.trim() === want && n.offsetParent !== null) || null;
    } else {
      el = document.querySelector(sel);
    }
    if (!el) throw new Error("selector not found: " + sel);
    if (act2 === "click") { el.scrollIntoView({ block: "center" }); el.click(); return "clicked"; }
    if (act2 === "type") {
      el.focus();
      const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, "value");
      if (setter && setter.set) setter.set.call(el, txt); else el.value = txt;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      return "typed";
    }
    throw new Error("bad action: " + act2);
  }, [d.selector, a, d.text || ""]);
}

async function shot(tabId) {
  const target = { tabId: tabId };
  await chrome.debugger.attach(target, "1.3");
  try {
    const r = await chrome.debugger.sendCommand(target, "Page.captureScreenshot", { format: "png" });
    return r.data;
  } finally { chrome.debugger.detach(target).catch(() => {}); }
}

async function handle(m) {
  const d = m.cmd || {};
  try {
    let out = null;
    switch (m.action) {
      case "ping": out = "pong"; break;
      case "tabs.list": {
        const ts = await chrome.tabs.query({});
        out = ts.map((t, i) => ({ index: i, tabId: t.id, title: t.title || "", url: t.url || "", active: !!t.active }));
        break;
      }
      case "tabs.new": {
        const t = await chrome.tabs.create({ url: d.url || "about:blank", active: false });
        await waitLoad(t.id);
        out = { tabId: t.id, url: d.url };
        break;
      }
      case "tabs.close": await chrome.tabs.remove(Number(d.tabId)); out = true; break;
      case "tabs.group": {
        const gid = await chrome.tabs.group({ tabIds: (d.tabIds || []).map(Number) });
        if (d.name) await chrome.tabGroups.update(gid, { title: d.name });
        out = { groupId: gid };
        break;
      }
      case "navigate": await chrome.tabs.update(Number(d.tabId), { url: d.url }); await waitLoad(Number(d.tabId)); out = true; break;
      case "act": out = await act(d); break;
      case "read": out = await runInTab(Number(d.tabId), () => (document.body ? document.body.innerText : "")); break;
      case "shot": out = await shot(Number(d.tabId)); break;
      default: throw new Error("unknown action: " + m.action);
    }
    reply(m, true, out);
  } catch (e) { reply(m, false, null, String((e && e.message) || e)); }
}

chrome.alarms.create("ka", { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === "ka") connect(); });
chrome.runtime.onStartup.addListener(connect);
connect();
